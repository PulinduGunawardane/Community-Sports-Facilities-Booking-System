using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SportsBookingSystem.Helpers;

namespace SportsBookingSystem.Helpers;

// Applied to controllers/actions that require a signed-in member
// (booking, payment, review submission, "my bookings"). Guests hitting
// these are redirected to the login page instead of getting a 401.
public class RequireMemberLoginAttribute : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext context)
    {
        if (!context.HttpContext.Session.IsLoggedIn())
        {
            context.Result = new RedirectToActionResult("Login", "Account", new { returnUrl = context.HttpContext.Request.Path });
        }
        base.OnActionExecuting(context);
    }
}
