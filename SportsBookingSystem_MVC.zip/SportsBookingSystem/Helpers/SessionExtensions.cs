namespace SportsBookingSystem.Helpers;

// ASP.NET Core's ISession only natively stores byte[]/string, so these
// small helpers wrap the "logged-in member" values used throughout the
// Member controllers.
public static class SessionExtensions
{
    private const string MemberIdKey = "MemberID";
    private const string MemberNameKey = "MemberName";

    public static void SignIn(this ISession session, int memberId, string memberName)
    {
        session.SetInt32(MemberIdKey, memberId);
        session.SetString(MemberNameKey, memberName);
    }

    public static void SignOut(this ISession session)
    {
        session.Remove(MemberIdKey);
        session.Remove(MemberNameKey);
    }

    public static int? GetMemberId(this ISession session) => session.GetInt32(MemberIdKey);

    public static string? GetMemberName(this ISession session) => session.GetString(MemberNameKey);

    public static bool IsLoggedIn(this ISession session) => session.GetMemberId() is not null;
}
