using Microsoft.Data.SqlClient;
using System.Data;
using SportsBookingSystem.Models;

namespace SportsBookingSystem.Data;

public class PaymentRepository
{
    private readonly DbHelper _db;

    public PaymentRepository(DbHelper db)
    {
        _db = db;
    }

    // Calls dbo.sp_ProcessPayment. Note that card details entered on the
    // checkout form are used only to drive the simulated UX flow — only
    // the payment method, amount, and a server-generated TransactionRef
    // are ever written to the database (see the stored procedure).
    public void ProcessPayment(int bookingId, string paymentMethod)
    {
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand("dbo.sp_ProcessPayment", conn) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@BookingID", bookingId);
        cmd.Parameters.AddWithValue("@PaymentMethod", paymentMethod);
        cmd.ExecuteNonQuery();
    }

    public Payment? GetByBookingId(int bookingId)
    {
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(
            "SELECT PaymentID, BookingID, Amount, PaymentMethod, PaymentStatus, PaymentDate, TransactionRef " +
            "FROM dbo.Payment WHERE BookingID = @BookingID;", conn);
        cmd.Parameters.AddWithValue("@BookingID", bookingId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;

        return new Payment
        {
            PaymentID = (int)reader["PaymentID"],
            BookingID = (int)reader["BookingID"],
            Amount = (decimal)reader["Amount"],
            PaymentMethod = (string)reader["PaymentMethod"],
            PaymentStatus = (string)reader["PaymentStatus"],
            PaymentDate = reader["PaymentDate"] as DateTime?,
            TransactionRef = reader["TransactionRef"] as string
        };
    }
}
