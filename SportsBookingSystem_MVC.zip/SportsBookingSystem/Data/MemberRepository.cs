using Microsoft.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using SportsBookingSystem.Models;

namespace SportsBookingSystem.Data;

public class MemberRepository
{
    private readonly DbHelper _db;

    public MemberRepository(DbHelper db)
    {
        _db = db;
    }

    // Registers a new member with a randomly generated salt + SHA-256 hash.
    // Returns the new MemberID, or null if the email is already registered.
    public int? Register(string firstName, string lastName, string email, string phone,
        string address, string password, List<int> sportTypeIds)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(16);
        byte[] hash = HashPassword(password, salt);

        using var conn = _db.GetConnection();
        conn.Open();

        using var checkCmd = new SqlCommand("SELECT COUNT(1) FROM dbo.Member WHERE Email = @Email", conn);
        checkCmd.Parameters.AddWithValue("@Email", email);
        if ((int)checkCmd.ExecuteScalar() > 0)
        {
            return null; // email already registered
        }

        using var transaction = conn.BeginTransaction();
        try
        {
            using var insertCmd = new SqlCommand(@"
                INSERT INTO dbo.Member (FirstName, LastName, Email, Phone, Address, PasswordHash, PasswordSalt)
                OUTPUT INSERTED.MemberID
                VALUES (@FirstName, @LastName, @Email, @Phone, @Address, @PasswordHash, @PasswordSalt);",
                conn, transaction);

            insertCmd.Parameters.AddWithValue("@FirstName", firstName);
            insertCmd.Parameters.AddWithValue("@LastName", lastName);
            insertCmd.Parameters.AddWithValue("@Email", email);
            insertCmd.Parameters.AddWithValue("@Phone", (object?)phone ?? DBNull.Value);
            insertCmd.Parameters.AddWithValue("@Address", (object?)address ?? DBNull.Value);
            insertCmd.Parameters.AddWithValue("@PasswordHash", hash);
            insertCmd.Parameters.AddWithValue("@PasswordSalt", salt);

            int newMemberId = (int)insertCmd.ExecuteScalar();

            foreach (var sportTypeId in sportTypeIds)
            {
                using var prefCmd = new SqlCommand(
                    "INSERT INTO dbo.MemberSportPreference (MemberID, SportTypeID) VALUES (@MemberID, @SportTypeID);",
                    conn, transaction);
                prefCmd.Parameters.AddWithValue("@MemberID", newMemberId);
                prefCmd.Parameters.AddWithValue("@SportTypeID", sportTypeId);
                prefCmd.ExecuteNonQuery();
            }

            transaction.Commit();
            return newMemberId;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    // Validates login credentials; returns the Member on success, null on failure.
    public Member? ValidateLogin(string email, string password)
    {
        using var conn = _db.GetConnection();
        conn.Open();

        using var cmd = new SqlCommand(@"
            SELECT MemberID, FirstName, LastName, Email, Phone, Address,
                   RegisteredDate, IsActive, PasswordHash, PasswordSalt
            FROM dbo.Member
            WHERE Email = @Email AND IsActive = 1;", conn);
        cmd.Parameters.AddWithValue("@Email", email);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;

        var storedHash = (byte[])reader["PasswordHash"];
        var storedSalt = (byte[])reader["PasswordSalt"];
        var computedHash = HashPassword(password, storedSalt);

        if (!CryptographicOperations.FixedTimeEquals(storedHash, computedHash))
        {
            return null;
        }

        return new Member
        {
            MemberID = (int)reader["MemberID"],
            FirstName = (string)reader["FirstName"],
            LastName = (string)reader["LastName"],
            Email = (string)reader["Email"],
            Phone = reader["Phone"] as string ?? string.Empty,
            Address = reader["Address"] as string ?? string.Empty,
            RegisteredDate = (DateTime)reader["RegisteredDate"],
            IsActive = (bool)reader["IsActive"]
        };
    }

    public List<SportType> GetAllSportTypes()
    {
        var list = new List<SportType>();
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand("SELECT SportTypeID, SportName FROM dbo.SportType ORDER BY SportName;", conn);
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            list.Add(new SportType
            {
                SportTypeID = (int)reader["SportTypeID"],
                SportName = (string)reader["SportName"]
            });
        }
        return list;
    }

    // Application-side hashing mirrors the SQL script's HASHBYTES('SHA2_256', ...)
    // approach: password bytes concatenated with a random salt, then SHA-256'd.
    private static byte[] HashPassword(string password, byte[] salt)
    {
        using var sha256 = SHA256.Create();
        var passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);
        var combined = new byte[passwordBytes.Length + salt.Length];
        Buffer.BlockCopy(passwordBytes, 0, combined, 0, passwordBytes.Length);
        Buffer.BlockCopy(salt, 0, combined, passwordBytes.Length, salt.Length);
        return sha256.ComputeHash(combined);
    }
}
