using Microsoft.Data.SqlClient;
using System.Data;
using SportsBookingSystem.Models;

namespace SportsBookingSystem.Data;

public class BookingRepository
{
    private readonly DbHelper _db;

    public BookingRepository(DbHelper db)
    {
        _db = db;
    }

    // Calls dbo.sp_CreateBooking, which runs the overlap check and the
    // Booking + Payment inserts inside one transaction (see SQL script,
    // section 7). Throws SqlException with the procedure's RAISERROR
    // message if the slot is unavailable — the controller catches this
    // and shows it to the user as a validation error.
    public int CreateBooking(int memberId, int facilityId, DateTime bookingDate, TimeSpan startTime, TimeSpan endTime)
    {
        using var conn = _db.GetConnection();
        conn.Open();

        using var cmd = new SqlCommand("dbo.sp_CreateBooking", conn) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@MemberID", memberId);
        cmd.Parameters.AddWithValue("@FacilityID", facilityId);
        cmd.Parameters.AddWithValue("@BookingDate", bookingDate.Date);
        cmd.Parameters.AddWithValue("@StartTime", startTime);
        cmd.Parameters.AddWithValue("@EndTime", endTime);

        var outputParam = new SqlParameter("@NewBookingID", SqlDbType.Int) { Direction = ParameterDirection.Output };
        cmd.Parameters.Add(outputParam);

        cmd.ExecuteNonQuery();
        return (int)outputParam.Value;
    }

    public List<Booking> GetBookingsForMember(int memberId)
    {
        var bookings = new List<Booking>();
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(@"
            SELECT b.BookingID, b.FacilityID, f.FacilityName, b.BookingDate, b.StartTime, b.EndTime,
                   b.Status, b.CreatedAt, p.Amount, p.PaymentStatus
            FROM dbo.Booking b
            JOIN dbo.Facility f ON f.FacilityID = b.FacilityID
            LEFT JOIN dbo.Payment p ON p.BookingID = b.BookingID
            WHERE b.MemberID = @MemberID
            ORDER BY b.BookingDate DESC, b.StartTime DESC;", conn);
        cmd.Parameters.AddWithValue("@MemberID", memberId);

        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            bookings.Add(new Booking
            {
                BookingID = (int)reader["BookingID"],
                FacilityID = (int)reader["FacilityID"],
                FacilityName = (string)reader["FacilityName"],
                BookingDate = (DateTime)reader["BookingDate"],
                StartTime = (TimeSpan)reader["StartTime"],
                EndTime = (TimeSpan)reader["EndTime"],
                Status = (string)reader["Status"],
                CreatedAt = (DateTime)reader["CreatedAt"],
                PaymentAmount = reader["Amount"] as decimal?,
                PaymentStatus = reader["PaymentStatus"] as string
            });
        }
        return bookings;
    }

    public Booking? GetById(int bookingId, int memberId)
    {
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(@"
            SELECT b.BookingID, b.FacilityID, f.FacilityName, b.BookingDate, b.StartTime, b.EndTime,
                   b.Status, b.CreatedAt, p.Amount, p.PaymentStatus
            FROM dbo.Booking b
            JOIN dbo.Facility f ON f.FacilityID = b.FacilityID
            LEFT JOIN dbo.Payment p ON p.BookingID = b.BookingID
            WHERE b.BookingID = @BookingID AND b.MemberID = @MemberID;", conn);
        cmd.Parameters.AddWithValue("@BookingID", bookingId);
        cmd.Parameters.AddWithValue("@MemberID", memberId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;

        return new Booking
        {
            BookingID = (int)reader["BookingID"],
            FacilityID = (int)reader["FacilityID"],
            FacilityName = (string)reader["FacilityName"],
            BookingDate = (DateTime)reader["BookingDate"],
            StartTime = (TimeSpan)reader["StartTime"],
            EndTime = (TimeSpan)reader["EndTime"],
            Status = (string)reader["Status"],
            CreatedAt = (DateTime)reader["CreatedAt"],
            PaymentAmount = reader["Amount"] as decimal?,
            PaymentStatus = reader["PaymentStatus"] as string
        };
    }
}
