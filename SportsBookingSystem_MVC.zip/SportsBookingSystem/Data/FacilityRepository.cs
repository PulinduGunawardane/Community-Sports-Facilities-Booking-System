using Microsoft.Data.SqlClient;
using System.Data;
using SportsBookingSystem.Models;

namespace SportsBookingSystem.Data;

public class FacilityRepository
{
    private readonly DbHelper _db;

    public FacilityRepository(DbHelper db)
    {
        _db = db;
    }

    // Calls the table-valued function dbo.fn_SearchFacilities — used by both
    // the member "Search Facilities" page and the guest "Restricted Search" page.
    public List<Facility> Search(string? facilityType, string? location, DateTime? bookingDate)
    {
        var results = new List<Facility>();

        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(
            "SELECT * FROM dbo.fn_SearchFacilities(@FacilityType, @Location, @BookingDate);", conn);

        cmd.Parameters.AddWithValue("@FacilityType", (object?)facilityType ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@Location", (object?)location ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@BookingDate", (object?)bookingDate ?? DBNull.Value);

        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            results.Add(MapFacility(reader, includeAvailability: true));
        }
        return results;
    }

    public Facility? GetById(int facilityId)
    {
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(@"
            SELECT FacilityID, FacilityName, FacilityType, Location, Capacity, HourlyRate, Status,
                   AverageRating, ReviewCount
            FROM dbo.vw_FacilityRatingSummary
            WHERE FacilityID = @FacilityID;", conn);
        cmd.Parameters.AddWithValue("@FacilityID", facilityId);

        using var reader = cmd.ExecuteReader();
        if (!reader.Read()) return null;

        return new Facility
        {
            FacilityID = (int)reader["FacilityID"],
            FacilityName = (string)reader["FacilityName"],
            FacilityType = (string)reader["FacilityType"],
            Location = (string)reader["Location"],
            Capacity = (int)reader["Capacity"],
            HourlyRate = (decimal)reader["HourlyRate"],
            Status = (string)reader["Status"],
            AverageRating = (decimal)reader["AverageRating"],
            ReviewCount = (int)reader["ReviewCount"]
        };
    }

    public List<string> GetDistinctFacilityTypes()
    {
        var types = new List<string>();
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand("SELECT DISTINCT FacilityType FROM dbo.Facility ORDER BY FacilityType;", conn);
        using var reader = cmd.ExecuteReader();
        while (reader.Read()) types.Add((string)reader["FacilityType"]);
        return types;
    }

    private static Facility MapFacility(SqlDataReader reader, bool includeAvailability)
    {
        var facility = new Facility
        {
            FacilityID = (int)reader["FacilityID"],
            FacilityName = (string)reader["FacilityName"],
            FacilityType = (string)reader["FacilityType"],
            Location = (string)reader["Location"],
            Capacity = (int)reader["Capacity"],
            HourlyRate = (decimal)reader["HourlyRate"],
            Status = (string)reader["Status"]
        };
        if (includeAvailability)
        {
            facility.DayAvailability = reader["DayAvailability"] as string ?? string.Empty;
        }
        return facility;
    }
}
