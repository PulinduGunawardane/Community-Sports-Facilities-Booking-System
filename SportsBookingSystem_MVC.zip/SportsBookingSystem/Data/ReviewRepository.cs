using Microsoft.Data.SqlClient;
using System.Data;
using SportsBookingSystem.Models;

namespace SportsBookingSystem.Data;

public class ReviewRepository
{
    private readonly DbHelper _db;

    public ReviewRepository(DbHelper db)
    {
        _db = db;
    }

    // Calls dbo.sp_SubmitReview, which validates server-side that the
    // member actually owns a confirmed/completed booking for this facility
    // before inserting — see the SQL script, section 7.
    public void SubmitReview(int memberId, int bookingId, int rating, string comment)
    {
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand("dbo.sp_SubmitReview", conn) { CommandType = CommandType.StoredProcedure };
        cmd.Parameters.AddWithValue("@MemberID", memberId);
        cmd.Parameters.AddWithValue("@BookingID", bookingId);
        cmd.Parameters.AddWithValue("@Rating", rating);
        cmd.Parameters.AddWithValue("@Comment", (object?)comment ?? DBNull.Value);
        cmd.ExecuteNonQuery();
    }

    // Guest and member "Review Search" — no login required to view.
    public List<Review> GetReviewsForFacility(int facilityId)
    {
        var reviews = new List<Review>();
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(@"
            SELECT r.ReviewID, r.MemberID, m.FirstName + ' ' + m.LastName AS MemberName,
                   r.FacilityID, f.FacilityName, r.BookingID, r.Rating, r.Comment, r.ReviewDate
            FROM dbo.Review r
            JOIN dbo.Member m ON m.MemberID = r.MemberID
            JOIN dbo.Facility f ON f.FacilityID = r.FacilityID
            WHERE r.FacilityID = @FacilityID
            ORDER BY r.ReviewDate DESC;", conn);
        cmd.Parameters.AddWithValue("@FacilityID", facilityId);

        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            reviews.Add(new Review
            {
                ReviewID = (int)reader["ReviewID"],
                MemberID = (int)reader["MemberID"],
                MemberName = (string)reader["MemberName"],
                FacilityID = (int)reader["FacilityID"],
                FacilityName = (string)reader["FacilityName"],
                BookingID = reader["BookingID"] as int?,
                Rating = (int)(byte)reader["Rating"],
                Comment = reader["Comment"] as string ?? string.Empty,
                ReviewDate = (DateTime)reader["ReviewDate"]
            });
        }
        return reviews;
    }

    // All reviews across every facility, for the guest-facing "browse reviews" page.
    public List<Review> GetAllReviews()
    {
        var reviews = new List<Review>();
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(@"
            SELECT r.ReviewID, r.MemberID, m.FirstName + ' ' + m.LastName AS MemberName,
                   r.FacilityID, f.FacilityName, r.BookingID, r.Rating, r.Comment, r.ReviewDate
            FROM dbo.Review r
            JOIN dbo.Member m ON m.MemberID = r.MemberID
            JOIN dbo.Facility f ON f.FacilityID = r.FacilityID
            ORDER BY r.ReviewDate DESC;", conn);

        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            reviews.Add(new Review
            {
                ReviewID = (int)reader["ReviewID"],
                MemberID = (int)reader["MemberID"],
                MemberName = (string)reader["MemberName"],
                FacilityID = (int)reader["FacilityID"],
                FacilityName = (string)reader["FacilityName"],
                BookingID = reader["BookingID"] as int?,
                Rating = (int)(byte)reader["Rating"],
                Comment = reader["Comment"] as string ?? string.Empty,
                ReviewDate = (DateTime)reader["ReviewDate"]
            });
        }
        return reviews;
    }
}
