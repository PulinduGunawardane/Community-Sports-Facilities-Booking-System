using Microsoft.Data.SqlClient;
using System.Data;

namespace SportsBookingSystem.Data;

public class InquiryRepository
{
    private readonly DbHelper _db;

    public InquiryRepository(DbHelper db)
    {
        _db = db;
    }

    public void SubmitInquiry(string guestName, string guestEmail, int? facilityId, string message)
    {
        using var conn = _db.GetConnection();
        conn.Open();
        using var cmd = new SqlCommand(@"
            INSERT INTO dbo.Inquiry (GuestName, GuestEmail, FacilityID, Message)
            VALUES (@GuestName, @GuestEmail, @FacilityID, @Message);", conn);
        cmd.Parameters.AddWithValue("@GuestName", guestName);
        cmd.Parameters.AddWithValue("@GuestEmail", guestEmail);
        cmd.Parameters.AddWithValue("@FacilityID", (object?)facilityId ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@Message", message);
        cmd.ExecuteNonQuery();
    }
}
