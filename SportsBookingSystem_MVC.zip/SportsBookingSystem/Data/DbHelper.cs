using Microsoft.Data.SqlClient;

namespace SportsBookingSystem.Data;

// Thin wrapper around the connection string so repositories don't each
// depend on IConfiguration directly.
public class DbHelper
{
    private readonly string _connectionString;

    public DbHelper(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("SportsBookingDB")
            ?? throw new InvalidOperationException("Connection string 'SportsBookingDB' was not found.");
    }

    public SqlConnection GetConnection() => new SqlConnection(_connectionString);
}
