using Microsoft.AspNetCore.Mvc;
using SportsBookingSystem.Data;
using SportsBookingSystem.Helpers;
using SportsBookingSystem.Models.ViewModels;

namespace SportsBookingSystem.Controllers;

// "Search Facilities" — member-only per the case study (guests get the
// separate, more limited GuestController.RestrictedSearch).
[RequireMemberLogin]
public class FacilityController : Controller
{
    private readonly FacilityRepository _facilityRepository;
    private readonly ReviewRepository _reviewRepository;

    public FacilityController(FacilityRepository facilityRepository, ReviewRepository reviewRepository)
    {
        _facilityRepository = facilityRepository;
        _reviewRepository = reviewRepository;
    }

    [HttpGet]
    public IActionResult Search()
    {
        var vm = new FacilitySearchViewModel
        {
            FacilityTypes = _facilityRepository.GetDistinctFacilityTypes(),
            Results = _facilityRepository.Search(null, null, null)
        };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Search(FacilitySearchViewModel model)
    {
        model.FacilityTypes = _facilityRepository.GetDistinctFacilityTypes();
        model.Results = _facilityRepository.Search(model.FacilityType, model.Location, model.BookingDate);
        return View(model);
    }

    public IActionResult Details(int id)
    {
        var facility = _facilityRepository.GetById(id);
        if (facility is null) return NotFound();

        ViewBag.Reviews = _reviewRepository.GetReviewsForFacility(id);
        return View(facility);
    }
}
