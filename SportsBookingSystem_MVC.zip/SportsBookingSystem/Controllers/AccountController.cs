using Microsoft.AspNetCore.Mvc;
using SportsBookingSystem.Data;
using SportsBookingSystem.Helpers;
using SportsBookingSystem.Models.ViewModels;

namespace SportsBookingSystem.Controllers;

public class AccountController : Controller
{
    private readonly MemberRepository _memberRepository;

    public AccountController(MemberRepository memberRepository)
    {
        _memberRepository = memberRepository;
    }

    [HttpGet]
    public IActionResult Register()
    {
        var vm = new RegisterViewModel { AvailableSports = _memberRepository.GetAllSportTypes() };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Register(RegisterViewModel model)
    {
        model.AvailableSports = _memberRepository.GetAllSportTypes();

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var newMemberId = _memberRepository.Register(
            model.FirstName, model.LastName, model.Email, model.Phone,
            model.Address, model.Password, model.PreferredSportTypeIds);

        if (newMemberId is null)
        {
            ModelState.AddModelError(nameof(model.Email), "An account with this email already exists.");
            return View(model);
        }

        HttpContext.Session.SignIn(newMemberId.Value, model.FirstName);
        TempData["SuccessMessage"] = $"Welcome, {model.FirstName}! Your membership is now active.";
        return RedirectToAction("Index", "Home");
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        ViewBag.ReturnUrl = returnUrl;
        return View(new LoginViewModel());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Login(LoginViewModel model, string? returnUrl = null)
    {
        ViewBag.ReturnUrl = returnUrl;

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var member = _memberRepository.ValidateLogin(model.Email, model.Password);
        if (member is null)
        {
            model.ErrorMessage = "Incorrect email or password.";
            return View(model);
        }

        HttpContext.Session.SignIn(member.MemberID, member.FirstName);

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
        {
            return Redirect(returnUrl);
        }
        return RedirectToAction("Index", "Home");
    }

    public IActionResult Logout()
    {
        HttpContext.Session.SignOut();
        return RedirectToAction("Index", "Home");
    }
}
