using Microsoft.AspNetCore.Mvc;
using SportsBookingSystem.Data;
using SportsBookingSystem.Helpers;
using SportsBookingSystem.Models.ViewModels;

namespace SportsBookingSystem.Controllers;

public class ReviewController : Controller
{
    private readonly ReviewRepository _reviewRepository;
    private readonly BookingRepository _bookingRepository;

    public ReviewController(ReviewRepository reviewRepository, BookingRepository bookingRepository)
    {
        _reviewRepository = reviewRepository;
        _bookingRepository = bookingRepository;
    }

    // Viewing reviews is open to guests and members alike (case study:
    // "Review Search" is a guest feature).
    public IActionResult FacilityReviews(int facilityId)
    {
        var reviews = _reviewRepository.GetReviewsForFacility(facilityId);
        return View(reviews);
    }

    [RequireMemberLogin]
    [HttpGet]
    public IActionResult Create(int bookingId)
    {
        var memberId = HttpContext.Session.GetMemberId()!.Value;
        var booking = _bookingRepository.GetById(bookingId, memberId);
        if (booking is null) return NotFound();

        var vm = new ReviewCreateViewModel { BookingID = bookingId, FacilityName = booking.FacilityName };
        return View(vm);
    }

    [RequireMemberLogin]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(ReviewCreateViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var memberId = HttpContext.Session.GetMemberId()!.Value;

        try
        {
            _reviewRepository.SubmitReview(memberId, model.BookingID, model.Rating, model.Comment);
            TempData["SuccessMessage"] = "Thanks — your review has been posted.";
            return RedirectToAction("MyBookings", "Booking");
        }
        catch (Microsoft.Data.SqlClient.SqlException ex)
        {
            model.ErrorMessage = ex.Message;
            return View(model);
        }
    }
}
