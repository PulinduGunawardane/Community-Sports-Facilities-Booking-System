using Microsoft.AspNetCore.Mvc;
using SportsBookingSystem.Data;
using SportsBookingSystem.Models.ViewModels;

namespace SportsBookingSystem.Controllers;

// All actions here are intentionally open to unauthenticated visitors —
// this controller implements the case study's "Guests" feature set:
// restricted search, review search, become-a-member, and send inquiry.
public class GuestController : Controller
{
    private readonly FacilityRepository _facilityRepository;
    private readonly ReviewRepository _reviewRepository;
    private readonly InquiryRepository _inquiryRepository;

    public GuestController(FacilityRepository facilityRepository, ReviewRepository reviewRepository,
        InquiryRepository inquiryRepository)
    {
        _facilityRepository = facilityRepository;
        _reviewRepository = reviewRepository;
        _inquiryRepository = inquiryRepository;
    }

    // Guests can browse facility type/location/availability broadly, but
    // the view deliberately omits exact time slots and the "Book" action
    // — that requires signing in (case study: "cannot access full booking
    // details without logging in").
    [HttpGet]
    public IActionResult RestrictedSearch()
    {
        var vm = new FacilitySearchViewModel
        {
            FacilityTypes = _facilityRepository.GetDistinctFacilityTypes(),
            Results = _facilityRepository.Search(null, null, null)
        };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult RestrictedSearch(FacilitySearchViewModel model)
    {
        model.FacilityTypes = _facilityRepository.GetDistinctFacilityTypes();
        model.Results = _facilityRepository.Search(model.FacilityType, model.Location, null);
        return View(model);
    }

    public IActionResult ReviewSearch()
    {
        var reviews = _reviewRepository.GetAllReviews();
        return View(reviews);
    }

    [HttpGet]
    public IActionResult Inquiry()
    {
        var vm = new InquiryCreateViewModel
        {
            AvailableFacilities = _facilityRepository.Search(null, null, null)
        };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Inquiry(InquiryCreateViewModel model)
    {
        model.AvailableFacilities = _facilityRepository.Search(null, null, null);

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        _inquiryRepository.SubmitInquiry(model.GuestName, model.GuestEmail, model.FacilityID, model.Message);

        return View("InquirySent", model.GuestName);
    }

    // "Become a Member" is simply the entry point into full registration.
    public IActionResult BecomeMember() => RedirectToAction("Register", "Account");
}
