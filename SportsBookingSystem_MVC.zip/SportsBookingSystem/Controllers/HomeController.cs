using Microsoft.AspNetCore.Mvc;
using SportsBookingSystem.Data;
using SportsBookingSystem.Helpers;

namespace SportsBookingSystem.Controllers;

public class HomeController : Controller
{
    private readonly FacilityRepository _facilityRepository;

    public HomeController(FacilityRepository facilityRepository)
    {
        _facilityRepository = facilityRepository;
    }

    // Public entry point for all users — sports council info, member
    // login/registration links, and a preview of available facilities.
    public IActionResult Index()
    {
        ViewBag.IsLoggedIn = HttpContext.Session.IsLoggedIn();
        ViewBag.MemberName = HttpContext.Session.GetMemberName();

        var facilities = _facilityRepository.Search(null, null, null);
        return View(facilities.Take(6).ToList());
    }

    public IActionResult Error() => View();
}
