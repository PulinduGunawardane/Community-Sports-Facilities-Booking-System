using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using SportsBookingSystem.Data;
using SportsBookingSystem.Helpers;
using SportsBookingSystem.Models.ViewModels;

namespace SportsBookingSystem.Controllers;

[RequireMemberLogin]
public class BookingController : Controller
{
    private readonly BookingRepository _bookingRepository;
    private readonly FacilityRepository _facilityRepository;

    public BookingController(BookingRepository bookingRepository, FacilityRepository facilityRepository)
    {
        _bookingRepository = bookingRepository;
        _facilityRepository = facilityRepository;
    }

    [HttpGet]
    public IActionResult Create(int facilityId)
    {
        var facility = _facilityRepository.GetById(facilityId);
        if (facility is null) return NotFound();

        var vm = new BookingCreateViewModel
        {
            FacilityID = facility.FacilityID,
            FacilityName = facility.FacilityName,
            HourlyRate = facility.HourlyRate
        };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(BookingCreateViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var memberId = HttpContext.Session.GetMemberId()!.Value;

        try
        {
            int newBookingId = _bookingRepository.CreateBooking(
                memberId, model.FacilityID, model.BookingDate, model.StartTime, model.EndTime);

            return RedirectToAction("Checkout", "Payment", new { bookingId = newBookingId });
        }
        catch (SqlException ex)
        {
            // Surfaces the RAISERROR message from sp_CreateBooking (e.g. slot
            // already booked, or end time before start time) directly to the user.
            model.ErrorMessage = ex.Message;
            return View(model);
        }
    }

    public IActionResult MyBookings()
    {
        var memberId = HttpContext.Session.GetMemberId()!.Value;
        var bookings = _bookingRepository.GetBookingsForMember(memberId);
        return View(bookings);
    }
}
