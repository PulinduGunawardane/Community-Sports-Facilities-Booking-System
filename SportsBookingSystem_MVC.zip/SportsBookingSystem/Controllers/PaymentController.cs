using Microsoft.AspNetCore.Mvc;
using SportsBookingSystem.Data;
using SportsBookingSystem.Helpers;
using SportsBookingSystem.Models.ViewModels;

namespace SportsBookingSystem.Controllers;

[RequireMemberLogin]
public class PaymentController : Controller
{
    private readonly BookingRepository _bookingRepository;
    private readonly PaymentRepository _paymentRepository;

    public PaymentController(BookingRepository bookingRepository, PaymentRepository paymentRepository)
    {
        _bookingRepository = bookingRepository;
        _paymentRepository = paymentRepository;
    }

    [HttpGet]
    public IActionResult Checkout(int bookingId)
    {
        var memberId = HttpContext.Session.GetMemberId()!.Value;
        var booking = _bookingRepository.GetById(bookingId, memberId);
        if (booking is null) return NotFound();

        if (booking.PaymentStatus == "Paid")
        {
            return RedirectToAction("Confirmation", new { bookingId });
        }

        var vm = new PaymentCheckoutViewModel
        {
            BookingID = booking.BookingID,
            FacilityName = booking.FacilityName,
            BookingDate = booking.BookingDate,
            StartTime = booking.StartTime,
            EndTime = booking.EndTime,
            Amount = booking.PaymentAmount ?? 0
        };
        return View(vm);
    }

    // Simulated checkout: the card fields are validated for shape only
    // (format-checked, never sent anywhere) and are NOT persisted. Only
    // dbo.sp_ProcessPayment's server-generated TransactionRef, the amount,
    // and the chosen payment method are written to the database.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Checkout(PaymentCheckoutViewModel model)
    {
        var memberId = HttpContext.Session.GetMemberId()!.Value;
        var booking = _bookingRepository.GetById(model.BookingID, memberId);
        if (booking is null) return NotFound();

        if (!ModelState.IsValid)
        {
            model.FacilityName = booking.FacilityName;
            model.BookingDate = booking.BookingDate;
            model.StartTime = booking.StartTime;
            model.EndTime = booking.EndTime;
            model.Amount = booking.PaymentAmount ?? 0;
            return View(model);
        }

        _paymentRepository.ProcessPayment(model.BookingID, "Card");
        return RedirectToAction("Confirmation", new { bookingId = model.BookingID });
    }

    public IActionResult Confirmation(int bookingId)
    {
        var memberId = HttpContext.Session.GetMemberId()!.Value;
        var booking = _bookingRepository.GetById(bookingId, memberId);
        if (booking is null) return NotFound();

        var payment = _paymentRepository.GetByBookingId(bookingId);
        ViewBag.Payment = payment;
        return View(booking);
    }
}
