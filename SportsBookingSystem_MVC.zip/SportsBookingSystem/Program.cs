using SportsBookingSystem.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Data access layer — thin ADO.NET repositories that call the stored
// procedures, views, and functions defined in SportsBookingSystem_Database.sql
builder.Services.AddScoped<DbHelper>();
builder.Services.AddScoped<MemberRepository>();
builder.Services.AddScoped<FacilityRepository>();
builder.Services.AddScoped<BookingRepository>();
builder.Services.AddScoped<PaymentRepository>();
builder.Services.AddScoped<ReviewRepository>();
builder.Services.AddScoped<InquiryRepository>();

// Session is used for the simple member login state (MemberID, MemberName).
// This keeps authentication straightforward for the coursework scope while
// still keeping credentials server-side only (no client-stored passwords).
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddHttpContextAccessor();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
