namespace SportsBookingSystem.Models;

public class Facility
{
    public int FacilityID { get; set; }
    public string FacilityName { get; set; } = string.Empty;
    public string FacilityType { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public int Capacity { get; set; }
    public decimal HourlyRate { get; set; }
    public string Status { get; set; } = string.Empty;

    // Populated from dbo.fn_SearchFacilities — not a physical column
    public string DayAvailability { get; set; } = string.Empty;

    // Populated from dbo.vw_FacilityRatingSummary
    public decimal AverageRating { get; set; }
    public int ReviewCount { get; set; }
}
