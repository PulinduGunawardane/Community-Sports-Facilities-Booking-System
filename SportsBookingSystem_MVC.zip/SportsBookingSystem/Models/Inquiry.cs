namespace SportsBookingSystem.Models;

public class Inquiry
{
    public int InquiryID { get; set; }
    public string GuestName { get; set; } = string.Empty;
    public string GuestEmail { get; set; } = string.Empty;
    public int? FacilityID { get; set; }
    public string Message { get; set; } = string.Empty;
    public DateTime SubmittedDate { get; set; }
    public string Status { get; set; } = string.Empty;
}
