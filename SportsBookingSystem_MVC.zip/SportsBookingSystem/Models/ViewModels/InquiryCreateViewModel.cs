using System.ComponentModel.DataAnnotations;

namespace SportsBookingSystem.Models.ViewModels;

public class InquiryCreateViewModel
{
    [Required, StringLength(100)]
    public string GuestName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(100)]
    public string GuestEmail { get; set; } = string.Empty;

    public int? FacilityID { get; set; }
    public List<Facility> AvailableFacilities { get; set; } = new();

    [Required, StringLength(500, MinimumLength = 10)]
    public string Message { get; set; } = string.Empty;

    public bool Submitted { get; set; }
}
