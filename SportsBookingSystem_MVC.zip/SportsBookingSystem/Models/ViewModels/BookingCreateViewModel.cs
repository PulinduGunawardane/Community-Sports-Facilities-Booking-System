using System.ComponentModel.DataAnnotations;

namespace SportsBookingSystem.Models.ViewModels;

public class BookingCreateViewModel
{
    public int FacilityID { get; set; }
    public string FacilityName { get; set; } = string.Empty;
    public decimal HourlyRate { get; set; }

    [Required]
    public DateTime BookingDate { get; set; } = DateTime.Today.AddDays(1);

    [Required]
    public TimeSpan StartTime { get; set; } = new TimeSpan(9, 0, 0);

    [Required]
    public TimeSpan EndTime { get; set; } = new TimeSpan(10, 0, 0);

    public string? ErrorMessage { get; set; }
}
