using System.ComponentModel.DataAnnotations;

namespace SportsBookingSystem.Models.ViewModels;

public class ReviewCreateViewModel
{
    public int BookingID { get; set; }
    public string FacilityName { get; set; } = string.Empty;

    [Required, Range(1, 5, ErrorMessage = "Rating must be between 1 and 5.")]
    public int Rating { get; set; } = 5;

    [StringLength(500)]
    public string Comment { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }
}
