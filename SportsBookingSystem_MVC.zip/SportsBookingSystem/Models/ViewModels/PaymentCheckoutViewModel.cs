using System.ComponentModel.DataAnnotations;

namespace SportsBookingSystem.Models.ViewModels;

public class PaymentCheckoutViewModel
{
    public int BookingID { get; set; }
    public string FacilityName { get; set; } = string.Empty;
    public DateTime BookingDate { get; set; }
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
    public decimal Amount { get; set; }

    // --- Simulated card details. NEVER persisted — used only to drive the
    // demo checkout UX. Only PaymentMethod, amount, and a generated
    // TransactionRef are ever written to the database (see sp_ProcessPayment). ---
    [Required, StringLength(19, MinimumLength = 12)]
    [Display(Name = "Card number")]
    public string CardNumber { get; set; } = string.Empty;

    [Required, StringLength(50)]
    [Display(Name = "Name on card")]
    public string CardHolderName { get; set; } = string.Empty;

    [Required, RegularExpression(@"^(0[1-9]|1[0-2])\/[0-9]{2}$", ErrorMessage = "Use MM/YY format.")]
    [Display(Name = "Expiry (MM/YY)")]
    public string ExpiryDate { get; set; } = string.Empty;

    [Required, StringLength(4, MinimumLength = 3)]
    public string CVV { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }
}
