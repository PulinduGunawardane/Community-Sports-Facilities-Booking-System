namespace SportsBookingSystem.Models.ViewModels;

public class FacilitySearchViewModel
{
    public string? FacilityType { get; set; }
    public string? Location { get; set; }
    public DateTime? BookingDate { get; set; }

    public List<Facility> Results { get; set; } = new();

    // Populated so the view can render a type dropdown
    public List<string> FacilityTypes { get; set; } = new();
}
