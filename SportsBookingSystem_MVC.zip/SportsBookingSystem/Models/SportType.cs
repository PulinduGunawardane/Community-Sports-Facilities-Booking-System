namespace SportsBookingSystem.Models;

public class SportType
{
    public int SportTypeID { get; set; }
    public string SportName { get; set; } = string.Empty;
}
