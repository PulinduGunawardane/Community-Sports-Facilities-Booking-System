namespace SportsBookingSystem.Models;

public class Review
{
    public int ReviewID { get; set; }
    public int MemberID { get; set; }
    public string MemberName { get; set; } = string.Empty;
    public int FacilityID { get; set; }
    public string FacilityName { get; set; } = string.Empty;
    public int? BookingID { get; set; }
    public int Rating { get; set; }
    public string Comment { get; set; } = string.Empty;
    public DateTime ReviewDate { get; set; }
}
