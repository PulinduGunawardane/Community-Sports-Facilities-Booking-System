namespace SportsBookingSystem.Models;

public class Payment
{
    public int PaymentID { get; set; }
    public int BookingID { get; set; }
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; } = string.Empty;
    public string PaymentStatus { get; set; } = string.Empty;
    public DateTime? PaymentDate { get; set; }
    public string? TransactionRef { get; set; }
}
