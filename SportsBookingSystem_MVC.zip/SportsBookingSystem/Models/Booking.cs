namespace SportsBookingSystem.Models;

public class Booking
{
    public int BookingID { get; set; }
    public int MemberID { get; set; }
    public int FacilityID { get; set; }
    public string FacilityName { get; set; } = string.Empty;
    public DateTime BookingDate { get; set; }
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }

    // Convenience fields joined in from Payment for the "My Bookings" list
    public decimal? PaymentAmount { get; set; }
    public string? PaymentStatus { get; set; }
}
